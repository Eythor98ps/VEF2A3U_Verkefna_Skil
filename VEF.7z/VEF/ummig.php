<?php
    session_start(); 
?>
<?php include'./includes/title.php';?>
<!DOCTYPE html>
<?php  include("./includes/head.php");?>
<body>
    <?php include("./includes/header.php") ?>
<div class="containall">
    <?php include("./includes/menu.php") ?>
    <main>
    	<p>Bla Bla</p>
    </main>
</div>
<?php include("./includes/footer.php") ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</body>
</html>